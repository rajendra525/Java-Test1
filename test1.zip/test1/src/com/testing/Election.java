package com.testing;

public class Election {
	
	     static int Count(String[]arr, String s)
	    {
	            int count = 0;
	            for (int j = 0; j < arr.length; j++)
	 
	               
	                if (s.equals(arr[j]))
	                    count++;
	 
	           return count;
	    }
	 
	    static void matchingString(String[] arr, String q[])
	    {
	        for (int i=0;i<q.length; i++)
	            System.out.print(Count(arr, q[i]) + " ");
	        
	    }
	 
	 
	    public static void main(String[] args) {
	 
	        String[] arr = {"john","johnny","jackie","johnny","john","jackie","jamie","jamie","john","johnny","jamie","johnny","john"};
	        String[] a  = {"john","johnny","jackie", "jamie"};
	        
			matchingString(arr, a);
	  
	    }
}

