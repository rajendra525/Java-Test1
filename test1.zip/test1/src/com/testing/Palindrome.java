package com.testing;

public class Palindrome {
	 public static int reverse( int number ) { 
	        int num = 0;
	        while ( number > 0 ) {
	            num= num * 10 + (number % 10);
	            number = number / 10;
	        }
	        return num;
	    }

	 
	    public static void main(String[] args) {
	        for ( int i =100; i < 1000; i++ ) {
	            if ( i == reverse( i ) ) {
	                System.out.println( i );
	            }
	        }
	    }
	}