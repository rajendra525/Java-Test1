package com.testing;

public class PeakElement {
public static void main(String[] args)
{
	int a [] = {10, 20, 15, 2, 23,90, 67};
	

	String r="";
	
	for(int i=0; i<a.length; i++) {
		
		if(i==0) {
			if(a[i]> a[i+1])
				r += a[i]+" ";
		}
		
		if(i>=1&&i<a.length-1) {
		if(a[i]>a[i+1]&&a[i] > a[i-1] ) 
				r += a[i]+" ";
		}
		
		if(i==a.length-1) {
			if(a[a.length-1] > a[a.length-2]) {
				r+= a[i]+" ";
			}
			
		}
	}	
		
	
	System.out.println(r);
}

}