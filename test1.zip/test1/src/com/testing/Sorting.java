package com.testing;
import java.util.*;

public class Sorting {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String args[])
	{
		
	
		List l = new ArrayList<Integer>();
		l.add(20);
		l.add(12);
		l.add(15);
		l.add(14);
		l.add(8);
		l.add(10);
		l.add(11);
		l.add(25);
		l.add(12);
		l.add(14);
		l.add(10);
		
		Set s = new TreeSet(l);
		l.clear();
		l.addAll(s);	
		System.out.println("without duplicates and after sorting"+l);
		
		
	}
}
